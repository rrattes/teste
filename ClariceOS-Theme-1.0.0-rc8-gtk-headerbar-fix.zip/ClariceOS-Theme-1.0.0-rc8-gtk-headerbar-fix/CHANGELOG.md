# Changelog

## 1.0.0-rc7-quicksettings-refined
- refined GNOME Shell Quick Settings surfaces
- improved control-box hierarchy in light and dark variants
- preserved RC6 continuous macOS-inspired top bar


## 1.0.0-rc8-gtk-headerbar-fix
- Refined GTK4/libadwaita headerbar height and padding
- Removed tabbar/viewswitcherbar from the shared headerbar treatment to avoid phantom thick bars
- Reduced window control/titlebutton sizing for GTK4 and GTK3
- Removed excess headerbar shadow to achieve a cleaner premium app chrome
