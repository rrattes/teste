# ClariceOS-Theme 1.0.0-rc8 — GTK headerbar fix

This package focuses on GTK application chrome after real-world testing.

## What was fixed
- Reduced the heavy/thick GTK4 headerbar treatment
- Removed the phantom secondary bar caused by over-styling tabbar/viewswitcherbar surfaces
- Tightened libadwaita / CSD window control button sizing
- Matched GTK3 headerbar/button sizing closer to the refined GTK4 look

## What to verify
- Files/Nautilus top bar
- GNOME Console / Terminal top chrome
- App close / maximize / minimize buttons
- Empty extra strip below the top bar should be gone or greatly reduced
