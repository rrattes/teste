# GTK_HEADERBAR_FIX_NOTES

This hotfix is based on real screenshots from the user's GNOME session.

## Observed issues
- Strange thick strip below app top bars
- Window control buttons not matching the expected GNOME/libadwaita proportions

## Root cause
The GTK4 theme treated headerbar, tabbar, viewswitcherbar, and tabbox as if they were all the same chrome layer.
That caused empty bars to inherit full headerbar height/background/border styles.

The theme also let generic button sizing leak into title buttons / window control buttons.

## Fix strategy
- Keep only real headerbars styled as headerbars
- Neutralize tabbar/viewswitcherbar/tabbox when they are acting as secondary/internal surfaces
- Override title buttons / window controls with a much tighter geometry
