# POPOVER_FIX_NOTES

## Root cause
The theme styled both the outer popover/menu and its internal `contents` node with
background, border, radius and shadow. That produced a 'frame inside frame' look.

## Fix strategy
- Keep the outer popover as the only true surface
- Make `contents` transparent and borderless
- Preserve padding, but remove duplicate framing
