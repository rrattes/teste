# ClariceOS-Theme 1.0.0-rc9 — Popover and menu fix

This package focuses on strange nested borders and framed interiors visible in menus/popovers.

## What was fixed
- Removed double-surface styling in GTK4/libadwaita popovers
- Stopped `contents` from receiving the same framed treatment as the outer popover
- Reduced odd nested borders in menus and dropdowns
- Added a light GTK3 fallback cleanup for menus/popovers

## What to verify
- Theme picker menus
- Dropdowns
- Menubutton popovers
- Small context menus
